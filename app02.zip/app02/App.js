import * as React from 'react';
import {View,Text,StyleSheet,Image,ScrollView} from 'react-native';

export default function App(){
return(
<View  style={estilo.container}>
<Text  style={estilo.titulo}> Praias lindas do Brasil</Text>
<Text  style={estilo.frase}>Minhas Férias...</Text>
<ScrollView style={estilo.fotos}>
<Image style={estilo.img} source={require("./assets/surf-g19c45899f_640.jpg")}/>
<Text  style={estilo.legenda}> Praia do Bom Bom</Text>
<Image style={estilo.img} source={require("./assets/motocross-g1c3c0a5dc_640.jpg")}/>
<Text  style={estilo.legenda}> Praia PCX</Text>
<Image style={estilo.img} source={require("./assets/maldives-g50a527c24_640.jpg")}/>
<Text  style={estilo.legenda}> São Vicente</Text>
</ScrollView>
</View>

);
} 

const estilo = StyleSheet.create({

container:{
flex:1,
backgroundColor:'#6495ED',

},


titulo: {
textAlign:'center',
fontSize:30,
marginTop: 50,
marginBottom:20,
fontWeight:'bold',
fontFamily:'Times New Roman',
color:'#F0F8FF',

},

frase:{
fontSize:15,
marginBottom:20,
textAlign:'right',
fontWeight:980,
},

img:{
 width:300,
 height:200,
 marginLeft:15,
 borderRadius:68,  

},

legenda:{
textAlign:'center',
fontSize:15,
fontFamily:'fantasy',
marginTop:10,
marginBottom:10,
},

fotos:{
alignItems:'center'
},







});